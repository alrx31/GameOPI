package com.example.field_of_miracles.data

class Scores {
    val arrayOfScores = listOf<Int>(220,180,260,120,280,240,-1,140,200,160,100,0,300)
}